package recu1.clases.curso;

import java.util.ArrayList;

public class Curso {
	private ArrayList<Alumno> padron;
	private ArrayList<Planilla> planillas;

	public Curso(ArrayList<Alumno> padronInicial) {
		padron = new ArrayList<>();
		planillas = new ArrayList<>();
		prepararPadron(padronInicial);
		inicializarPlanillas();
	}

	private void prepararPadron(ArrayList<Alumno> padronInicial) {
		for (Alumno alumno : padronInicial) {
			padron.add(alumno);
		}
	}

	public ArrayList<Alumno> devolverAlumnosCoincidentes(Rubro rubro, Calificacion calificacion) {
		ArrayList<Alumno> alumnos = new ArrayList<>();
		alumnos.addAll(obtenerPlanilla(rubro).devolverAlumnoConCalificacion(calificacion));
		return alumnos;
	}

	private Alumno buscarAlumno(int dni) {
		Alumno alumno = null;
		int pos = 0;
		while (pos < padron.size() && padron.get(pos).getDni() < dni)
			pos++;
		if (pos < padron.size() && padron.get(pos).getDni() == dni)
			alumno = padron.get(pos);
		return alumno;
	}

	// TODO - Modificar lo que devuelve este metodo para que en vez de devolver las
	// notas que no se procesaron "crudas" devuelva una clase con la nota sin
	// procesar por error mas un codigo de error.
	// Lo que hace planilla.cargarItem no es importante, salvo que devuelve true si
	// la nota pudo procesarse o false si la nota esta repetida (si ya estaba
	// cargada de antes).
	public ArrayList<Nota> generarPlanillas(ArrayList<Nota> notas) {
		Planilla planilla;
		Alumno alumno;
		Nota nota;
		int pos = 0;
		// mientras no se procesen todas las notas
		while (pos < notas.size()) {
			nota = notas.get(pos);
			alumno = buscarAlumno(nota.getDniAlumno());
			if (alumno != null) {
				// Si el alumno existe...
				planilla = obtenerPlanilla(nota.getRubro());
				if (planilla.cargarItem(alumno, nota.getCalificacion())) {
					// nota procesada, se remueve.
					notas.remove(nota);
				} else {
					// Error: La nota ya habia sido procesada (ya estaba cargada)
					pos++;
				}
			} else {
				// Error: el dni que vino en la nota no pertenece a un alumno existente en el
				// padron.
				pos++;
			}
		}
		return notas;
	}

	private void inicializarPlanillas() {
		planillas.clear();
		for (Rubro rubro : Rubro.values()) {
			planillas.add(new Planilla(rubro));
		}
	}

	private Planilla obtenerPlanilla(Rubro rubro) {
		return planillas.get(rubro.ordinal());
	}

}