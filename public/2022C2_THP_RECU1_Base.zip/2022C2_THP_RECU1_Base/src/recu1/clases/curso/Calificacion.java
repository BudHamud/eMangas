package recu1.clases.curso;

public enum Calificacion {
	NO_EVALUADO, DESAPROBADO, APROBADO;
}