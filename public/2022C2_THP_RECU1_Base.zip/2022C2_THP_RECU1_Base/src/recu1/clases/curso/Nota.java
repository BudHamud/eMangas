package recu1.clases.curso;

public class Nota {
	private int dniAlumno;
	private Rubro rubro;
	private Calificacion calificacion;

	public Nota(int dniAlumno, Rubro rubro, Calificacion calificacion) {
		this.setDniAlumno(dniAlumno);
		this.rubro = rubro;
		this.calificacion = calificacion;
	}

	public int getDniAlumno() {
		return dniAlumno;
	}

	private void setDniAlumno(int dniAlumno) {
		this.dniAlumno = dniAlumno;
	}

	public Rubro getRubro() {
		return rubro;
	}

	public Calificacion getCalificacion() {
		return calificacion;
	}

	@Override
	public String toString() {
		return "Nota [dniAlumno=" + dniAlumno + ", rubro=" + rubro + ", calificacion=" + calificacion + "]";
	}

}