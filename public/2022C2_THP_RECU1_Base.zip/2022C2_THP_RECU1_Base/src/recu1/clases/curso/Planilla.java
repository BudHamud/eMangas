package recu1.clases.curso;

import java.util.ArrayList;

public class Planilla {

	private ArrayList<Item> items;
	private Rubro rubro;

	public Planilla(Rubro rubro) {
		this.rubro = rubro;
		items = new ArrayList<>();
	}

	private Item buscarItemDeAlumno(Alumno alumno) {
		Item item = null;
		int pos = 0;
		while (pos < items.size() && !items.get(pos).perteneceAlAlumno(alumno))
			pos++;
		if (pos < items.size())
			item = items.get(pos);
		return item;
	}

	public boolean cargarItem(Alumno alumno, Calificacion calificacion) {
		Item item = buscarItemDeAlumno(alumno);
		if (item == null)
			items.add(new Item(alumno, calificacion));
		return item == null;
	}

	public ArrayList<Alumno> devolverAlumnoConCalificacion(Calificacion calificacion) {
		ArrayList<Alumno> alumnos = new ArrayList<>();
		for (Item item : items) {
			if (item.mismaCalificacion(calificacion))
				alumnos.add(item.getAlumno());
		}
		return alumnos;
	}

	public Rubro getRubro() {
		return rubro;
	}

}
