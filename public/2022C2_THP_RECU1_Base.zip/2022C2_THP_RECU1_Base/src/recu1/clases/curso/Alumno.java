package recu1.clases.curso;

public class Alumno {

	private int dni;
	private String nombre;

	public Alumno(int dni, String nombre) {
		this.dni = dni;
		this.nombre = nombre;
	}
	
	public int getDni() {
		return dni;
	}

	public String getNombre() {
		return nombre;
	}

	@Override
	public String toString() {
		return "Alumno [dni=" + dni + ", nombre=" + nombre + "]";
	}

}
