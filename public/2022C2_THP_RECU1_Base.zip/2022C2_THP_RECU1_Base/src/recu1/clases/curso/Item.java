package recu1.clases.curso;

public class Item {

	private Alumno alumno;
	private Calificacion calificacion;

	public Item(Alumno alumno, Calificacion calificacion) {
		this.alumno = alumno;
		this.calificacion = calificacion;
	}

	public boolean perteneceAlAlumno(Alumno alumno) {
		return this.alumno.equals(alumno);
	}
	
	public boolean mismaCalificacion(Calificacion calificacion) {
		return this.calificacion.equals(calificacion);
	}

	@Override
	public String toString() {
		return "Item [alumno=" + alumno + ", calificacion=" + calificacion + "]";
	}

	public Alumno getAlumno() {
		return alumno;
	}

}
