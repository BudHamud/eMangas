package recu1.clases.curso;

public enum Rubro {
	TRABAJOS_PRACTICOS,
	PARTICIPACION_EN_CLASE,
	CAMARA_ENCENDIDA,
	EXAMENES
}
