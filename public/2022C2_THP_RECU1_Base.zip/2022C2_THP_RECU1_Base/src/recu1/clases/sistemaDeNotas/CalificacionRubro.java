package recu1.clases.sistemaDeNotas;

import recu1.clases.curso.Calificacion;
import recu1.clases.curso.Rubro;

public class CalificacionRubro {
	private Rubro rubro;
	private Calificacion calificacion;
	public CalificacionRubro(Rubro rubro, Calificacion calificacion) {
		this.rubro = rubro;
		this.calificacion = calificacion;
	}
	public Rubro getRubro() {
		return rubro;
	}
	public Calificacion getCalificacion() {
		return calificacion;
	}
	public void setCalificacion(Calificacion calificacion) {
		this.calificacion = calificacion;
	}
	
}