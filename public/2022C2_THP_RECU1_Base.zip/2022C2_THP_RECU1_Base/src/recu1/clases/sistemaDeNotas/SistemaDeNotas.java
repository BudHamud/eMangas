package recu1.clases.sistemaDeNotas;

import java.util.ArrayList;

import recu1.clases.curso.Calificacion;
import recu1.clases.curso.Rubro;

/**
 * Simula otro sistema que provee el padron de alumnos y las calificaciones
 * guardadas durante el desarrollo del curso.
 *
 */
public class SistemaDeNotas {

	// Guarda los datos de todos los alumnos existentes con el detalle de su
	// calificacion en cada uno de los rubros que se quieren evaluar.
	private ArrayList<AlumnoCalificado> datos;

	public SistemaDeNotas() {
		datos = new ArrayList<>();
		generarInformacion();
	}

	private void generarInformacion() {
		// Primero creamos un alumno que no recibir� ninguna nota
		AlumnoCalificado ac = crearYAgregarDNI(10000000, "Alumno Del Curso");
		// Ahora creamos los alumnos simulados que recibiran calificaciones.
		ac = crearYAgregarDNI(21222320, "Elmas Viejillo");
		ac.cargarCalificacion(Rubro.CAMARA_ENCENDIDA, Calificacion.APROBADO);
		ac.cargarCalificacion(Rubro.EXAMENES, Calificacion.APROBADO);
		ac.cargarCalificacion(Rubro.TRABAJOS_PRACTICOS, Calificacion.APROBADO);
		// --
		ac = crearYAgregarDNI(28741361, "Augusto Primo Leibowitz");
		ac.cargarCalificacion(Rubro.CAMARA_ENCENDIDA, Calificacion.DESAPROBADO);
		ac.cargarCalificacion(Rubro.EXAMENES, Calificacion.DESAPROBADO);
		ac.cargarCalificacion(Rubro.TRABAJOS_PRACTICOS, Calificacion.DESAPROBADO);
		// --
		ac = crearYAgregarDNI(30306162, "Segundo Sombra");
		ac.cargarCalificacion(Rubro.CAMARA_ENCENDIDA, Calificacion.DESAPROBADO);
		ac.cargarCalificacion(Rubro.EXAMENES, Calificacion.APROBADO);
		ac.cargarCalificacion(Rubro.TRABAJOS_PRACTICOS, Calificacion.APROBADO);
		// --
		ac = crearYAgregarDNI(36214783, "Triana Lopez");
		ac.cargarCalificacion(Rubro.CAMARA_ENCENDIDA, Calificacion.APROBADO);
		ac.cargarCalificacion(Rubro.EXAMENES, Calificacion.DESAPROBADO);
		ac.cargarCalificacion(Rubro.TRABAJOS_PRACTICOS, Calificacion.APROBADO);
		// --
		ac = crearYAgregarDNI(37197184, "Mariana Gonzalez Quarta");
		ac.cargarCalificacion(Rubro.CAMARA_ENCENDIDA, Calificacion.APROBADO);
		ac.cargarCalificacion(Rubro.EXAMENES, Calificacion.APROBADO);
		ac.cargarCalificacion(Rubro.TRABAJOS_PRACTICOS, Calificacion.APROBADO);
		// --
		ac = crearYAgregarDNI(39215415, "Quintino Bocalluvia");
		ac.cargarCalificacion(Rubro.CAMARA_ENCENDIDA, Calificacion.DESAPROBADO);
		ac.cargarCalificacion(Rubro.EXAMENES, Calificacion.DESAPROBADO);
		ac.cargarCalificacion(Rubro.TRABAJOS_PRACTICOS, Calificacion.APROBADO);
		// --
		ac = crearYAgregarDNI(42302116, "Canino Sexto");
		ac.cargarCalificacion(Rubro.CAMARA_ENCENDIDA, Calificacion.DESAPROBADO);
		ac.cargarCalificacion(Rubro.EXAMENES, Calificacion.APROBADO);
		ac.cargarCalificacion(Rubro.TRABAJOS_PRACTICOS, Calificacion.DESAPROBADO);
	}

	private AlumnoCalificado crearYAgregarDNI(int dni, String nombre) {
		AlumnoCalificado alumno = new AlumnoCalificado(dni, nombre);
		datos.add(alumno);
		return alumno;
	}

	/**
	 * Devuelve los alumnos existentes en el padron ya cargados en el sistema
	 * 
	 * @return Una coleccion con los datos resumidos de un alumno (solamente su DNI
	 *         y su nombre completo)
	 */
	// TODO - Modificar el encabezado para que el metodo devuelva lo que corresponde 
	public ArrayList<?> obtenerPadronAlumnos() {
		// TODO Completar y modificar el return para que devuelva lo que corresponda
		return null;
	}

	/**
	 * Devuelve las notas de los alumnos ya cargados en el sistema
	 * 
	 * @return Una coleccion con las notas de todos los alumnos en el formato
	 *         requerido por el Curso
	 */
	// TODO - Modificar el encabezado para que el metodo devuelva lo que corresponde 
	public ArrayList<?> obtenerNotasDelSistema() {
		// TODO Completar con lo que haga falta

		// TODO -- Para asegurar el buen testeo y chequear el error de procesamiento por
		// nota repetida, reinsertar al final la nota guardada en el primer lugar de
		// toda la coleccion (la posicion 0) para que aparezca dos veces y dispare el
		// error de duplicado.

		// TODO -- generar una nota para un alumno que no existe para probar el error de
		// alumno inexistente en padron de la clase que maneja los datos del curso.
		// usar los datos 0 (cero, para el dni), Rubro.CAMARA_ENCENDIDA y Calificacion.NO_EVALUADO
		
		// TODO -- Modificar el return para que devuelva lo que corresponda
		return null;
	}
}