package recu1.clases.sistemaDeNotas;

import java.util.ArrayList;

import recu1.clases.curso.Calificacion;
import recu1.clases.curso.Rubro;

public class AlumnoCalificado {
	private int dni;
	private String nombreCompleto;
	private ArrayList<CalificacionRubro> calificaciones;

	public AlumnoCalificado(int dni, String nombreCompleto) {
		this.dni = dni;
		this.nombreCompleto = nombreCompleto;
		inicializarCalificaciones();
	}

	public void cargarCalificacion(Rubro rubro, Calificacion calificacion) {
		calificaciones.get(rubro.ordinal()).setCalificacion(calificacion);
	}

	private void inicializarCalificaciones() {
		calificaciones = new ArrayList<>();
		for (Rubro rubro : Rubro.values()) {
			calificaciones.add(new CalificacionRubro(rubro, Calificacion.NO_EVALUADO));
		}
	}

	// TODO -- Completar con los metodos que se piden para alimentar con datos a
	// usar en Curso.

}
