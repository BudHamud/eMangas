package recu1;

import java.util.ArrayList;

import recu1.clases.curso.Alumno;
import recu1.clases.curso.Calificacion;
import recu1.clases.curso.Curso;
import recu1.clases.curso.Nota;
import recu1.clases.curso.Rubro;
import recu1.clases.sistemaDeNotas.SistemaDeNotas;

public class Recu1 {

	public static void main(String[] args) {
		SistemaDeNotas sn = new SistemaDeNotas();
		// TODO - Modificar las dos lineas de abajo para alimentar a Curso con lo que
		// entrega el Sistema de Notas
		Curso curso = new Curso(new ArrayList<Alumno>());
		ArrayList<Nota> notas = curso.generarPlanillas(new ArrayList<Nota>());
		listaTutti(notas);
		ArrayList<Alumno> alumnos = new ArrayList<>();
		System.out.println("\nAlumnos con los examenes aprobados");
		System.out.println("**********************************");
		alumnos = curso.devolverAlumnosCoincidentes(Rubro.EXAMENES, Calificacion.APROBADO);
		listaTutti(alumnos);
	}

	private static void listaTutti(ArrayList<?> coleccion) {
		for (Object elemento : coleccion) {
			System.out.println(elemento);
		}
	}

}
